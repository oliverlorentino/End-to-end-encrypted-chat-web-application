import hashlib
import requests
def key_strength_sure(password):
    sha1 = hashlib.sha1(password.encode('utf-8')).hexdigest().upper()
    prefix = sha1[:5]
    suffix = sha1[5:]
    api = f"https://api.pwnedpasswords.com/range/{prefix}"
    response = requests.get(api)
    for line in response.text.splitlines():
        if suffix in line:
            return False
    return True

print(key_strength_sure('1regdfgdfg1'))
