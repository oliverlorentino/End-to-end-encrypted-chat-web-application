from datetime import datetime

from flask import Flask, request, render_template, redirect, url_for, session, flash
from util import send_verification_email, can_send, gen_captcha_image, bcrypt_encrypt, bcrypt_validate, recover_key, \
    key_strength_sure
import pymysql
from flask_session import Session
import yaml
import base64

app = Flask(__name__, static_folder='./static')

# Configure secret key and Flask-Session
app.config.from_pyfile('configure.py')
app.config['SESSION_TYPE'] = 'filesystem'  # Options: 'filesystem', 'redis', 'memcached', etc.
app.config['SESSION_PERMANENT'] = False
app.config['SESSION_USE_SIGNER'] = True  # To sign session cookies for extra security
app.config['SESSION_FILE_DIR'] = './sessions'  # Needed if using filesystem type

with open('db.yaml', 'r') as file:
    db_config = yaml.safe_load(file)


def get_db_connection():
    connection = pymysql.connect(host=db_config['mysql_host'],
                                 user=db_config['mysql_user'],
                                 password=db_config['mysql_password'],
                                 db=db_config['mysql_db'],
                                 charset='utf8mb4',
                                 cursorclass=pymysql.cursors.DictCursor)
    return connection


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        emails = request.form['registerEmail']
        connection = get_db_connection()
        cur = connection.cursor()
        query = 'SELECT * FROM users WHERE email = %s'
        params = (emails,)
        cur.execute(query, params)
        result = cur.fetchone()
        connection.close()
        if result is not None:
            flash("Already exit email")
            return render_template('login.html')
        flag = can_send()  # you can only use this per 60s
        if flag:
            vcode = send_verification_email(emails)
            session['email'] = emails
            session['register_code'] = vcode
            return redirect(url_for('registerCode'))
        else:
            flash("frequent asking wait and sign up")

    return render_template('login.html')


@app.route('/registerCode', methods=['POST', 'GET'])
def registerCode():
    if 'register_code' not in session:
        return redirect(url_for('register'))
    if request.method == 'POST':
        vcode = request.form['code']
        if session['register_code'] == vcode:
            session['code_validate'] = True
            return redirect(url_for('userInfo'))
        else:
            flash("Invalid validation code !")

    return render_template('registerCode.html')


@app.route('/userInfo', methods=['POST', 'GET'])
def userInfo():
    if 'code_validate' not in session:
        return redirect(url_for('registerCode'))
    if request.method == 'POST':
        user_name = request.form['userName']
        password = request.form['password']
        confirm_password = request.form['confirmpassword']

        connection = get_db_connection()
        cur = connection.cursor()
        query = 'SELECT * FROM users WHERE username = %s'
        params = (user_name,)
        cur.execute(query, params)
        result = cur.fetchone()
        connection.close()
        if result is not None:
            flash("Already exit username")
            return render_template('userInfo.html')

        if not key_strength_sure(password):
            flash("weak password")
            return render_template('userInfo.html')

        if password != confirm_password:
            flash('Passwords not match. Try again!')
            return render_template('userInfo.html')
        cipher, salt = bcrypt_encrypt(password)
        salt = base64.b64encode(salt).decode('utf-8')
        cipher = base64.b64encode(cipher).decode('utf-8')
        connection = get_db_connection()
        cur = connection.cursor()
        save_sql = "INSERT INTO users (username, email, created_at) VALUES (%s, %s,%s);"
        cur.execute(save_sql, (user_name, session['email'], datetime.now()))
        connection.commit()

        cur.execute('SELECT LAST_INSERT_ID()')
        user_id = cur.fetchone()['LAST_INSERT_ID()']

        save_sql2 = "INSERT INTO user_passwords (user_id,password_cipher,salt,recovery_key) VALUES (%s,%s, %s,%s);"
        recoverKey = recover_key()
        cur.execute(save_sql2, (user_id, cipher, salt, recoverKey))
        connection.commit()
        connection.close()
        session.pop('code_validate', None)
        session['chat_allow'] = True
        flash("keep your recoverey key: " + recoverKey)
        return redirect(url_for('chat'))

    return render_template('userInfo.html')


@app.route('/code', methods=['GET', 'POST'])
def code():
    if 'code_permit' not in session:
        return redirect(url_for('email'))

    if request.method == 'GET':
        return render_template('code.html')

    else:
        user_code = request.form['code']

        if 'email_code' in session and session['email_code'] == user_code:

            session['chat_allow'] = True
            return redirect(url_for('chat'))
        else:
            flash('Verification code is incorrect. Please try again.')
            return render_template('code.html')


@app.route('/email', methods=['GET', 'POST'])
def email():
    if 'username' not in session:
        return redirect(url_for('login'))
    if request.method == 'POST':
        email = request.form['email']
        if 'chat_allow' in session and not can_send():
            return redirect(url_for('chat'))

        connection = get_db_connection()
        cur = connection.cursor()
        query = 'SELECT email FROM users WHERE username = %s'
        params = (session['username'],)
        cur.execute(query, params)
        result = cur.fetchone()
        if result is None:
            flash(session['username'])
            connection.close()
            return render_template('email.html')

        if result['email'] != email:
            connection.close()
            flash("unmatched email")
            return render_template('email.html')

        vcode = send_verification_email(email)
        session['email'] = email
        session['email_code'] = vcode
        session['code_permit'] = True
        connection.close()
        return redirect(url_for('code'))
    else:
        return render_template('email.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    global picture_code
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        captcha = request.form['captcha']
        if 'picture_code' not in session or captcha != session['picture_code']:
            session['picture_code'] = gen_captcha_image()
            flash('Invalid validation code')
            return render_template('login.html')

        connection = get_db_connection()
        cur = connection.cursor()
        query = 'SELECT user_id FROM users WHERE username = %s'
        params = (username,)
        cur.execute(query, params)

        # get number of query, fetchcone I think works the same since db is small
        result = cur.fetchone()
        if result is None:
            flash('Invalid username')
            connection.close()
            return render_template('login.html')
        user_id = result['user_id']
        query2 = 'SELECT password_cipher,salt FROM user_passwords WHERE user_id = %s'
        params = (user_id,)
        cur.execute(query2, params)
        result2 = cur.fetchone()
        password_cipher = result2['password_cipher']
        salt = result2['salt']
        salt = base64.b64decode(salt.encode('utf-8'))
        password_cipher = base64.b64decode(password_cipher.encode('utf-8'))
        connection.close()
        if not bcrypt_validate(password_cipher, salt, password):
            flash("wrong password")
            return render_template('login.html')

        session['username'] = username
        return redirect(url_for('email'))
    session['picture_code'] = gen_captcha_image()
    return render_template('login.html')


@app.route('/chat', methods=['GET', 'POST'])
def chat():
    return render_template('chat.html')


@app.route('/')
def home():
    return render_template('home.html')


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=61117)
