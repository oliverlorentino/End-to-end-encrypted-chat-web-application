import random
import string
import smtplib
import time
import hashlib
from PIL import Image, ImageDraw, ImageFont
from email.mime.text import MIMEText
from email.header import Header
import bcrypt
import requests

flag = True
last_time = time.time()


# lecture 5 slide 19
def bcrypt_encrypt(password):
    password_bytes = password.encode('utf-8')
    sha256 = hashlib.sha256(password_bytes).digest()
    salt = bcrypt.gensalt()
    bcrypt256 = bcrypt.hashpw(sha256, salt)

    return bcrypt256, salt


def bcrypt_validate(cipher, salt, password):
    cipher2 = password.encode('utf-8')
    sha2562 = hashlib.sha256(cipher2).digest()
    bcrypt2562 = bcrypt.hashpw(sha2562, salt)
    return cipher == bcrypt2562


def recover_key():  # length must larger than 24
    l = string.ascii_lowercase
    u = string.ascii_uppercase
    d = string.digits
    s = string.punctuation
    key = ''
    i = random.randint(24, 40)
    for ii in range(i):
        key += random.choice(l + u + d + s)
    return key


def key_strength_sure(password):
    sha1 = hashlib.sha1(password.encode('utf-8')).hexdigest().upper()
    prefix = sha1[:5]
    suffix = sha1[5:]
    api = f"https://api.pwnedpasswords.com/range/{prefix}"
    response = requests.get(api)
    for line in response.text.splitlines():
        if suffix in line:
            return False
    return True


def can_send():
    global flag
    global last_time
    if flag:
        flag = False
        last_time = time.time()
        return True
    if time.time() - last_time > 60:
        last_time = time.time()
        return True
    return False


def generate_verification_code(length):
    digits = "0123456789"
    code = "".join(random.choice(digits) for _ in range(length))
    return code


def send_verification_email(receive_mail):
    # reused code from my repository:
    # https://github.com/oliverlorentino/COMP3211_GroupProject_Year3Sem1

    verification_code = generate_verification_code(6)
    global smtpObj
    message = MIMEText(verification_code, 'plain', 'utf-8')
    message['From'] = Header("admin", 'utf-8')
    message['To'] = Header("user", 'utf-8')

    # subject
    subject = 'Events notify' \
              '' \
              '' \
              '' \
              ''
    message['Subject'] = Header(subject, 'utf-8')

    try:
        # SMTP
        smtpObj = smtplib.SMTP('smtp.gmail.com', 587)  # SMTP service
        smtpObj.starttls()  # safe connects TLS
        smtpObj.login('oliverlorentino@gmail.com', 'jcfl djiv mgjn ytju')  # Application password of the GMAIL account
        smtpObj.sendmail('oliverlorentino@gmail.com', receive_mail, message.as_string())  # send mail
    except smtplib.SMTPException as e:
        print("Error: ；mail send fail", e)
    finally:
        smtpObj.quit()

    return verification_code


def random_captcha_text(char_set, captcha_size=4):
    captcha_text = ''
    for i in range(captcha_size):
        c = random.choice(char_set)
        captcha_text += c
    return captcha_text


def gen_captcha_image():
    image = Image.new('RGB', (100, 50), (255, 255, 255))
    font = ImageFont.load_default()
    draw = ImageDraw.Draw(image)

    captcha_text = random_captcha_text('0123456789ABCDEFGHIJKLMNPQRSTUVWXYZ', 4)
    draw.text((10, 10), captcha_text, font=font, fill=(0, 0, 255))

    for i in range(5):
        x1 = random.randint(0, 100)
        y1 = random.randint(0, 100)
        x2 = random.randint(0, 100)
        y2 = random.randint(0, 100)
        draw.line((x1, y1, x2, y2), fill=(0, 0, 255))

    image.save('static/captcha.jpg', 'jpeg')

    return captcha_text
